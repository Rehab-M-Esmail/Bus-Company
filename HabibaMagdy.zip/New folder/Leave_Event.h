#include "Event.h"
#include "Passenger.h"
class LeaveEvents : public Events {
private:
	Passenger* passenger;
public:

	LeaveEvents() : Events()
	{
		ID = 0;
		START = 0;
		Hour = 0;
		Min = 0;
	}

	LeaveEvents(int ID,int Start,int Hour,int minute) : Events() 
	{
		Hours = Hour;
		Min = minute;
		ID = id;
		STRT = Start;
	}

	Passenger* execute() override 
	{
		passenger = new Passenger(passengerType, id, hours, mins, startStation, endStation, OnoffTime, priority);
		return passenger;
	} 

	int get_id () override
	{
		return ID;
	}
};