#ifndef EVENT
#define EVENT
#include <iostream>
#include "Passenger.h"
using namespace std;
class Events {
protected:
    string Priority, Passenger_Typ;
    int  Hour, Min,On_OffTime , ID, START, END;

public:
    virtual Passenger* execute() = 0;
    virtual int getID() = 0;
};
#endif