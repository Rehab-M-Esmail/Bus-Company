#include "Event.h"
class ArrivalEvents : public Events {
private:
		Passenger* passenger;
public:
	string Priority, Passenger_Typ;
	int  Hour, Min, On_OffTime, ID, START, END;

	ArrivalEvents() : Events() 
	{
		ID = 0;
		START = 0;
		END=0;
		Passenger_Typ = "no";
		Priority = "no";
		Hour = 0;
		Min = 0;
		passenger = nullptr;

	}
	
	ArrivalEvents(string ptype, string priority, int id,int Start,int end,int hour,int min,int On_off_Time) : Events() 
	{
		Passenger_Typ = ptype;
		ID = id;
		START = Start;
		END = end;
		Hour = hour;
		Min = min;		
		if(!priority.empty()){
		Priority = priority;
		}
		else
		{
			Priority = "Normal";
		}
		passenger = nullptr;
		On_OffTime = On_off_Time;
	}

	Passenger* execute() override 
	{
		passenger = new Passenger(passengerType,id, hours ,mins, startStation, endStation, OnoffTime, priority);
		return passenger;
	}

	int getID()override
	{
		return ID;
	}
};